// server.js

const express = require('express');
const fs = require('fs');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
const PORT = 3000;
const DATA_FILE = 'data.json';

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(express.static(path.join(__dirname)));

// Route to serve the form
app.get('/form', (req, res) => {
    res.sendFile(path.join(__dirname, 'form.html'));
});

// API route to handle POST request and store data
app.post('/api/create', (req, res) => {
    const newEntry = {
        id: req.body.id,
        artist_name: req.body.artist_name,
        song_name: req.body.song_name,
        rating: req.body.rating
    };

    // Read existing data
    fs.readFile(DATA_FILE, 'utf8', (err, data) => {
        if (err && err.code !== 'ENOENT') {
            return res.status(500).send('Error reading data file.');
        }

        let jsonData = data ? JSON.parse(data) : [];
        jsonData.push(newEntry);

        // Write updated data
        fs.writeFile(DATA_FILE, JSON.stringify(jsonData, null, 2), (err) => {
            if (err) {
                return res.status(500).send('Error writing to data file.');
            }
            res.send('Song data added successfully!');
        });
    });
});

// Route to return all data
app.get('/api/data', (req, res) => {
    fs.readFile(DATA_FILE, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Error reading data file.');
        }
        res.json(JSON.parse(data));
    });
});

// Route to search by query string
app.get('/api/search', (req, res) => {
    const searchQuery = req.query.q.toLowerCase();
    fs.readFile(DATA_FILE, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Error reading data file.');
        }
        const jsonData = JSON.parse(data);
        const results = jsonData.filter(entry => 
            entry.artist_name.toLowerCase().includes(searchQuery) || 
            entry.song_name.toLowerCase().includes(searchQuery)
        );
        res.json(results);
    });
});

// Dynamic route to get data by ID
app.get('/api/data/:id', (req, res) => {
    const id = req.params.id;
    fs.readFile(DATA_FILE, 'utf8', (err, data) => {
        if (err) {
            return res.status(500).send('Error reading data file.');
        }
        const jsonData = JSON.parse(data);
        const result = jsonData.find(entry => entry.id == id);
        if (result) {
            res.json(result);
        } else {
            res.status(404).send('Data not found.');
        }
    });
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}/form`);
});
